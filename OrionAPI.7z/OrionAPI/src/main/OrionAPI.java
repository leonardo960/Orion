package main;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URISyntaxException;


public class OrionAPI {
	
	/**
	 * Must be called right before the game is closed in order to send Orion
	 * the experience points the User has gained in the last play session.
	 * 
	 * Note: Orion doesn't impose any restriction to developers as to how much
	 * experience is sent to the platform; we nevertheless reserve the right
	 * to analyze the data passed and adjust the real experience assigned to
	 * players if we feel it's unbalanced.
	 * @param exp the experience you think is appropriate to give for the play
	 * session 
	 */
	static public void commitExp(int exp){
		try {
			File savefile = new File(OrionAPI.class.getProtectionDomain().getCodeSource().getLocation().toURI().getPath() + "savefile.txt");
			FileWriter fw = new FileWriter(savefile);
			fw.write("" + exp);
			fw.close();
		} catch (URISyntaxException e) {
			System.out.println("Invalid path");
			e.printStackTrace();
		} catch (IOException e) {
			System.out.println("Error performing I/O");
			e.printStackTrace();
		}
	}
}
